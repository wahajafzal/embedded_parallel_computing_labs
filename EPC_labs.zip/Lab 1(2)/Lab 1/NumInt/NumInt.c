/**************************************************************
* NumInt.c - Sequential numerical integration example.      
* NumInt uses a trapeziod integration approximation        
*                                                            
**************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  double a=1.0;      /* lower integration bound */
  double b=4.0;      /* upper integration bound */
  double n=4800;       /* number of trapetzoids   */
  double integral;  
  double trap(double a, double b,double n);

  
  /*-------------------------------------------------------------------*/
  /* This program can be started with a value for n                    */
  /* Example numint 4800 starts the program with n set to 4800 */
   
  if(argc>1){
	n= (double) atof(argv[1]);
	if ( n<=0){
		n=4800;
		printf("argument for n not a valid number. Setting n to 4800\n");
	}
  }
  /*-------------------------------------------------------------------*/

  integral=trap(a,b,n);
  printf("The integral from %f to %f = %f using %f samples\n", a, b, integral, n);
  return(0);
}

float trap(double a, double b, double n)
{
  double h;
  double x;
  double integral;
  double f(double x);

  h = (b-a)/  n;
  integral=0.5*(f(a)+f(b));
  
  for(x = a +h ; x < b; x += h){
    integral = integral + f(x);
  }
  integral=integral*h;
  return integral;
}

float f(double x)
{

  x=x*x;
  return x;
}


