/* Epiphany test application */
#include <stdint.h>
#include <e_lib.h>

typedef struct {
	uint32_t test;
    unsigned int row;
    unsigned int col;
    unsigned long long total_cycles;
    float integral;
    int bb;
        
} shm_t;

unsigned int row, col;
unsigned int timer_count;
unsigned long long total_cycles;

volatile shm_t shm SECTION(".shared_dram");

void delay()
{
	for(volatile int i = 0; i < 1000000; i++)
		for(volatile int j = 0; j < 100; j++)
			;
}

void chk_timer_count()
{
    unsigned long long timer_clk;
    
    timer_clk = e_ctimer_get(E_CTIMER_0);
    
    if(timer_clk <= 0)
    {
        timer_count++;
        e_ctimer_set(E_CTIMER_0, E_CTIMER_MAX);
        e_ctimer_start(E_CTIMER_0, E_CTIMER_CLK);
    }
    
}

void init_timer()
{
    timer_count=0;
    e_ctimer_set(E_CTIMER_0, E_CTIMER_MAX);
    e_ctimer_start(E_CTIMER_0, E_CTIMER_CLK);
}

void calc_time()
{
    unsigned long long timer_clk;
    
    timer_clk = E_CTIMER_MAX - e_ctimer_get(E_CTIMER_0);
    
    total_cycles = ((timer_count*E_CTIMER_MAX)+timer_clk);
    
}
//
// int nn = 0;
// int n = 4800;
// double a = 1.0;
// double b = 4.0;
// double na = 0.0;
// double nb = 0.0;
// int in = 0;
// double nc = 4.0;
// float prev = 0;
// float delta = 0.0;


int main()
{
    double integral;  
    float trap(double a, double b,double n);

    int nn;
    int in;
    int n = 9600;
    double a = 1.0;
    double b = 4.0;
    double z = 0.0;
    double nc = 16.0;
    double na;
    double nb;
    float delta = 0.0;

    
    init_timer ();
    
    e_coords_from_coreid(e_get_coreid(), &row, &col);
    
    if (row == 0 && col == 0){
        shm.bb = 0;
        shm.integral = 0.0;
    
    }
    shm.row = row;
    shm.col = col;

    nn = 4*row + col;
    z = b - a;
    delta = z/nc;
    
    na = a + nn*delta;
    nb = a +(nn + 1)*delta;
    
    in = n/nc;
    integral = trap(na, nb, in);
    
    shm.integral += integral;       
   
    
    chk_timer_count();
    calc_time();
    shm.total_cycles = total_cycles;
    shm.bb += 1; 
    
    
    while(1);
}

float trap(double a, double b, double n)
{
  float h;
  float x;
  float integral;
  double f(double x);
  

  h = (b-a)/  n;
  integral=0.5*(f(a)+f(b));
  for(x = a +h ; x < b; x += h){
    integral = integral + f(x);
  }
  
  integral=integral*h;
  
  return integral;
}

double f(double x)
{

    x=x*x;
    return x;
}
