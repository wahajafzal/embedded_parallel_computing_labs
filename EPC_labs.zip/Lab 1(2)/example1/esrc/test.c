/* Epiphany test application */
#include <stdint.h>
#include <e_lib.h>

typedef struct {
	uint32_t test;
    unsigned int row;
    unsigned int col;
    unsigned long long total_cycles;
    uint32_t test1;
    unsigned int row1;
    unsigned int col1;
    unsigned long long total_cycles1;
} shm_t;

unsigned int row, col;
unsigned int timer_count;
unsigned long long total_cycles;

volatile shm_t shm SECTION(".shared_dram");

void delay()
{
	for(volatile int i = 0; i < 1000000; i++)
		for(volatile int j = 0; j < 100; j++)
			;
}

void chk_timer_count()
{
    unsigned long long timer_clk;
    
    timer_clk = e_ctimer_get(E_CTIMER_0);
    
    if(timer_clk <= 0)
    {
        timer_count++;
        e_ctimer_set(E_CTIMER_0, E_CTIMER_MAX);
        e_ctimer_start(E_CTIMER_0, E_CTIMER_CLK);
    }
    
}

void init_timer()
{
    timer_count=0;
    e_ctimer_set(E_CTIMER_0, E_CTIMER_MAX);
    e_ctimer_start(E_CTIMER_0, E_CTIMER_CLK);
}

void calc_time()
{
    unsigned long long timer_clk;
    
    timer_clk = E_CTIMER_MAX - e_ctimer_get(E_CTIMER_0);
    
    total_cycles = ((timer_count*E_CTIMER_MAX)+timer_clk);
    
}


int main()
{
    init_timer ();
    
    e_coords_from_coreid(e_get_coreid(), &col, &row);
    
    if ( row == 3) {
        shm.row = row;
        shm.col = col;
    
        shm.test = 3;
        delay();

        shm.test = 4;
        delay();

        shm.test = 5;
        delay();

        shm.test = 10;
    
        chk_timer_count();
        calc_time();
        shm.total_cycles = total_cycles;

    }
    
    else {
        shm.row1 = row;
        shm.col1 = col;
    
        shm.test1 = 3;
        delay();

        shm.test1 = 4;
        delay();

        shm.test1 = 5;
        delay();

        shm.test1 = 10;
   
        chk_timer_count();
        calc_time();
        shm.total_cycles1 = total_cycles;    
    }

    
    while(1);
}
