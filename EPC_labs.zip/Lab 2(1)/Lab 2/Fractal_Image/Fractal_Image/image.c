#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "image.h"

/* Bare-bones implementation of basic image handling for the PGM (Portable
 * GreyMap) file format.
 *
 * Notes/Limits:
 *      - No color support
 *      - Not full file format spec is implemented. Ie comments are not
 *        supported
 *      - Error handling is very basic
 *      - Text based file format DO NOT WORK. Try to fing bug...
 *
 */


/* Allocate memory and load a PGM file from disk.
 *
 * NOTE - Not full file format is supported. Comments are NOT allowed in file.
 *
 * Returns: NULL on error and pointer to img struct on success.
 */
img *load_image(char *filename)
{
  FILE    *fp;
  char    file_type[3],data2[5];
  int     i;
  img     *a;
  
    if ( (fp = fopen(filename,"r")) == NULL ) {
        return (img *)NULL;
    }

    fscanf(fp,"%2s",file_type);

    if ((strncmp("P2",(const char*)file_type,2)==0)||(strncmp("P5",(const char*)file_type,2)==0)){

        a = (img *)malloc( sizeof(img) );
        fscanf(fp," %d %d %d ",&a->width,&a->hight,&a->depth);

        if ( ( a->data = (char *)malloc( image_size(a) ) ) == NULL ) {
            fclose(fp);
            return (img *)NULL;
        }

        if ( strncmp("P5",(const char*)file_type,2) == 0 ) {
            for ( i=0; i<image_size(a) ; i++) {
                fscanf(fp,"%1c",(a->data)+i );
            }
        } else {
            for ( i=0; i<image_size(a) ; i++) {
                fscanf(fp,"%3s ",data2);
                *(a->data)=atoi(data2);
                (a->data)++;
            }
        }
    } else {
        /* File type not supported */
    }

    fclose(fp);

    return a;
}


/*
 * Saves a PGM file to disk. Both binary and textbased format is supported.
 *
 * Returns: 1 == OK / NULL == FAIL
 */
int save_image(img *a, char *filename, int binary)
{
  FILE *fp;
  int  i;
  char data[3];

    if ( (fp = fopen(filename,"w")) == NULL ) {
        return (int)NULL;    /* Could not open file */
    }

    if (binary) {
        fprintf(fp,"P5\n");
    } else {
        fprintf(fp,"P2\n");
    }

    fprintf(fp,"%d %d\n%d\n",a->width,a->hight,a->depth);

    if (binary) {
        for ( i=0; i<image_size(a) ; i++) {
            fprintf(fp,"%1c",*((a->data)+i));
        }
    } else {
        for ( i=0; i<image_size(a) ; i++) {
	    sprintf( data,"%d ",*((a->data)+i)&0x00FF );
            fprintf(fp,"%s",data);
        }
    }
    
    fclose(fp);

    return 1;
}


/* Allocates memory for a new image.
 *
 * Returns: Pointer to image == OK / NULL == FAIL
 */
img *new_image(int w, int h)
{
    img *a;

    if ( ( a=(img *)malloc(sizeof(img)) ) == NULL ) {
    	return (img *)NULL;
    }

    a->width = w;
    a->hight = h;
    a->depth = 255;

    if ( ( a->data = (char *)malloc(w*h) ) == NULL ) {
    	return (img *)NULL;
    }

    return a;
}


/* Sets position x,y to level
 */
void set_pixel(img *a, int x, int y, char level)
{
    if ( (x<0) || (y<0) || (y>a->hight) || (x>a->width) ) {
        printf("Out of range [%d,%d]\n",x,y);
	exit(1);
    }
    *(a->data+a->width*y+x)= level;
}


/* Get level at position x,y
 */
char get_pixel(img *a, int x, int y)
{
    if ( (x<0) || (y<0) || (y>a->hight) || (x>a->width) ) return 0;
    return *(a->data+x+a->width*y);
}


/* Calculates image size
 */
int image_size(img *a)
{
    return a->width * a->hight;
}
