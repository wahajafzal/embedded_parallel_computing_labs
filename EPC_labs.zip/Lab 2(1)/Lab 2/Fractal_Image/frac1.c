/*  Program to Calculate Fractal image in Sequential manner */
 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "image.h"

struct comp 
{
	double r;
	double i;
};

int main (int argc, char *argv[])
{
													/* Decalaration of Local variables */
	img *A,*B,*C;       
	int j, n;
	double tmp;
	int d_min,d_max;
													/* Size of the Image Decalaration */
	int k,l;
	int Max_Iteration=64;
		
	double x_min,y_min;
	double x_max,y_max;
	double x,y,x_step,y_step;
	
	struct comp c,z;
	double Abs_z;
	int image[Max_Iteration][Max_Iteration];
	int data[Max_Iteration][Max_Iteration];
	
	k=l=Max_Iteration;
	x_min=-1.5,y_min=-1.5;							/* Range of the image points */
	x_max=1.5,y_max=1.5;
													/* Create new empty image */
	C = new_image(k,l);
	B = new_image(k,l);	  
    												/* Calculating the points of new image */       	
        x=x_min;
	y=y_min;	
	x_step=(x_max-x_min)/l;
	y_step=(y_max-y_min)/k;
													
													/* Fractal Image Generation */
	for (k=0 ; k<Max_Iteration; k++ )
	{
		x=x_min; 
			
		for (l=0 ; l<Max_Iteration; l++) 
		{
			n=0;
			z.r=0;	z.i=0;
			c.r=x;	c.i=y;
			Abs_z=0;
		      		
			while( n<Max_Iteration  &&  Abs_z <2 ) 
			{
		  		z.r=pow(z.r,2) - pow(z.i,2);
		  		z.i=2*z.r*z.i;
		  		z.r=z.r+c.r;
		  		z.i=z.i+c.i;
		  		Abs_z=sqrt( pow(z.r,2) + pow(z.i,2) );
		  		n++;
			}
						
			data[k][l]=n;
			x=x+x_step;
		}
		    	
		y=y+y_step;
	}
	
		
	for(k=0;k<Max_Iteration;k++)
	{
		for(l=0;l<Max_Iteration;l++)
		{
			image[k][l]=data[k][l];
		}
	}
												/* Setting Pixels in Image data */
	for(k=0;k<Max_Iteration;k++)
	{
		for(l=0;l<Max_Iteration;l++)
	  	{
	   		set_pixel(B, k, l, image[k][l]);
	  	}
	}
	
	save_image(B,"B.pgm",1);   
	
	return 0;
}
