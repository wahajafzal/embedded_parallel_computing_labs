/* Epiphany Host Application */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include <e-loader.h>  // Comment this line if you are using old SDK ver 5.13.09.10

#include "e-hal.h"

#define FAIL(...) { fprintf(stderr, __VA_ARGS__); exit(1); }
#define SHM_OFFSET 0x01000000



typedef struct {
	uint32_t test;
    unsigned int row;
    unsigned int col;
    unsigned long long total_cycles;
    float integral;
    int bb;
    int image[64][64];
        
} shm_t;


int nc = 16;
int ncr = 4;
int ncc = 4;
clock_t start_t, end_t;

int main(int argc, char *argv[])
{
    start_t = clock(); 
	char *filename = "bin/test.srec";
	shm_t oldshm, shm;		/* local copies of shared memory */

	e_epiphany_t dev;
	e_mem_t      emem;

	e_set_host_verbosity(H_D0);
	e_set_loader_verbosity(L_D0);

	/* init board, reset epiphany, open workgroup */
	if(e_init(NULL) != E_OK)
		FAIL("Can't init!\n");
	e_reset_system();
	if(e_open(&dev, 0, 0, 4, 4) != E_OK)
		FAIL("Can't open!\n");

	/* initialize, allocate and update shared memory buffer */
	if(e_alloc(&emem, SHM_OFFSET, sizeof(shm_t)) != E_OK)
		FAIL("Can't alloc!\n");
	if(e_write(&emem, 1, 2, (off_t)0, &shm, sizeof(shm_t)) == E_ERR)
		FAIL("Can't clear shm!\n");


    for (volatile int i = 0; i < ncr; i++){
        for (volatile int j = 0; j < ncc; j++){
    	/* load program */
        	if(e_load(filename, &dev, i, j, E_TRUE) != E_OK)
        		FAIL("Can't load!\n");
            }
        }
	/* =============================================================== */
	while(1) {
		/* poll shm states for changes */
		printf("Polling shared memory.\n");

		while(1) {
			/* read shm */
			if(e_read(&emem, 1, 2, (off_t)0, &shm,
				sizeof(shm_t)) == E_ERR)
					FAIL("Can't poll!\n");

			/* compare with previous, break if different */
			if(memcmp(&oldshm, &shm, sizeof(shm_t)))
				break;
		};

		/* print value, exit if 10 */
		printf("Processor ID (%d, %d) total_cycles: %llu \n", shm.row, shm.col);

		if(shm.bb == nc)
			break;

		/* save shm */
		memcpy(&oldshm, &shm, sizeof(shm_t));
	}
	/* =============================================================== */

    end_t = clock();
    printf("Total time taken by CPU: %f\n", end_t - start_t  );
	printf("Program finished.\n");

	/* free shm buffer, close workgroup and finalize */
	if(e_free(&emem) != E_OK) FAIL("Can't free!\n");
	if(e_close(&dev) != E_OK) FAIL("Can't close!\n");
	if(e_finalize() != E_OK)  FAIL("Can't finalize!\n");

	return(0);
}

