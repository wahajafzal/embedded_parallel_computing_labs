/* Epiphany test application */
#include <stdint.h>
#include <e_lib.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "image.h"

typedef struct {
	uint32_t test;
    unsigned int row;
    unsigned int col;
    unsigned long long total_cycles;
    float integral;
    int bb;
    int image[64][64];
        
} shm_t;

unsigned int row, col;
unsigned int timer_count;
unsigned long long total_cycles;

volatile shm_t shm SECTION(".shared_dram");

img *load_image(char *filename)
{
  FILE    *fp;
  char    file_type[3],data2[5];
  int     i;
  img     *a;
  
    if ( (fp = fopen(filename,"r")) == NULL ) {
        return (img *)NULL;
    }

    fscanf(fp,"%2s",file_type);

    if ((strncmp("P2",(const char*)file_type,2)==0)||(strncmp("P5",(const char*)file_type,2)==0)){

        a = (img *)malloc( sizeof(img) );
        fscanf(fp," %d %d %d ",&a->width,&a->hight,&a->depth);

        if ( ( a->data = (char *)malloc( image_size(a) ) ) == NULL ) {
            fclose(fp);
            return (img *)NULL;
        }

        if ( strncmp("P5",(const char*)file_type,2) == 0 ) {
            for ( i=0; i<image_size(a) ; i++) {
                fscanf(fp,"%1c",(a->data)+i );
            }
        } else {
            for ( i=0; i<image_size(a) ; i++) {
                fscanf(fp,"%3s ",data2);
                *(a->data)=atoi(data2);
                (a->data)++;
            }
        }
    } else {
        /* File type not supported */
    }

    fclose(fp);

    return a;
}


/*
 * Saves a PGM file to disk. Both binary and textbased format is supported.
 *
 * Returns: 1 == OK / NULL == FAIL
 */
int save_image(img *a, char *filename, int binary)
{
  FILE *fp;
  int  i;
  char data[3];

    if ( (fp = fopen(filename,"w")) == NULL ) {
        return (int)NULL;    /* Could not open file */
    }

    if (binary) {
        fprintf(fp,"P5\n");
    } else {
        fprintf(fp,"P2\n");
    }

    fprintf(fp,"%d %d\n%d\n",a->width,a->hight,a->depth);

    if (binary) {
        for ( i=0; i<image_size(a) ; i++) {
            fprintf(fp,"%1c",*((a->data)+i));
        }
    } else {
        for ( i=0; i<image_size(a) ; i++) {
	    sprintf( data,"%d ",*((a->data)+i)&0x00FF );
            fprintf(fp,"%s",data);
        }
    }
    
    fclose(fp);

    return 1;
}


/* Allocates memory for a new image.
 *
 * Returns: Pointer to image == OK / NULL == FAIL
 */
img *new_image(int w, int h)
{
    img *a;

    if ( ( a=(img *)malloc(sizeof(img)) ) == NULL ) {
    	return (img *)NULL;
    }

    a->width = w;
    a->hight = h;
    a->depth = 255;

    if ( ( a->data = (char *)malloc(w*h) ) == NULL ) {
    	return (img *)NULL;
    }

    return a;
}


/* Sets position x,y to level
 */
void set_pixel(img *a, int x, int y, char level)
{
    if ( (x<0) || (y<0) || (y>a->hight) || (x>a->width) ) {
        printf("Out of range [%d,%d]\n",x,y);
	exit(1);
    }
    *(a->data+a->width*y+x)= level;
}


/* Get level at position x,y
 */
char get_pixel(img *a, int x, int y)
{
    if ( (x<0) || (y<0) || (y>a->hight) || (x>a->width) ) return 0;
    return *(a->data+x+a->width*y);
}


/* Calculates image size
 */
int image_size(img *a)
{
    return a->width * a->hight;
}


void delay()
{
	for(volatile int i = 0; i < 1000000; i++)
		for(volatile int j = 0; j < 100; j++)
			;
}

void chk_timer_count()
{
    unsigned long long timer_clk;
    
    timer_clk = e_ctimer_get(E_CTIMER_0);
    
    if(timer_clk <= 0)
    {
        timer_count++;
        e_ctimer_set(E_CTIMER_0, E_CTIMER_MAX);
        e_ctimer_start(E_CTIMER_0, E_CTIMER_CLK);
    }
    
}

void init_timer()
{
    timer_count=0;
    e_ctimer_set(E_CTIMER_0, E_CTIMER_MAX);
    e_ctimer_start(E_CTIMER_0, E_CTIMER_CLK);
}

void calc_time()
{
    unsigned long long timer_clk;
    
    timer_clk = E_CTIMER_MAX - e_ctimer_get(E_CTIMER_0);
    
    total_cycles = ((timer_count*E_CTIMER_MAX)+timer_clk);
    
}
//
// int nn = 0;
// int n = 4800;
// double a = 1.0;
// double b = 4.0;
// double na = 0.0;
// double nb = 0.0;
// int in = 0;
// double nc = 4.0;
// float prev = 0;
// float delta = 0.0;
struct comp 
{
	double r;
	double i;
};

int main()
{
    

    int nn;
    int in;
    double a = 4.0;
    double b = 4.0;
    double z = 0.0;
    double nc = 16.0;
    double na;
    double nb;
    float delta = 0.0;
    int aux_bb;
    
    e_coords_from_coreid(e_get_coreid(), &row, &col);
    
    if (row == 0 && col == 0){
        shm.bb = 0;
        //shm.integral = 0.0;
    
    }
    shm.row = row;
    shm.col = col;

    nn = 4*row + col;
    
    img *A,*B,*C;       
	int j, n;
	double tmp;
	int d_min,d_max;
													/* Size of the Image Decalaration */
	int k,l;
	int Max_Iteration=64;
		
	double x_min,y_min;
	double x_max,y_max;
	double x,y,x_step,y_step;
	
	struct comp c,z;
	double Abs_z;
	
	
	int sizex = 64/nc;
	int sizey = 64;
	int data[sizey][sizex];
	
	
    
	
	k=l=Max_Iteration;
	x_min=-1.5,y_min=-1.5;							/* Range of the image points */
	x_max=1.5,y_max=1.5;
													/* Create new empty image */
	C = new_image(k,l);
	B = new_image(k,l);	  
    												/* Calculating the points of new image */       	
    
	x_step=(x_max-x_min)/l;
	y_step=(y_max-y_min)/k;
	
	int alpha = 64/nc;
    int beta = alpha*nn;                            //offset
    
    x_min=x_min + x_step*beta;
	y=y_min;	
    
    
    for (k=0 ; k<sizey; k++ )
	{
		x=x_min; 
			
		for (l=0 ; l<sizex; l++) 
		{
			n=0;
			z.r=0;	z.i=0;
			c.r=x;	c.i=y;
			Abs_z=0;
		      		
			while( n<Max_Iteration  &&  Abs_z <2 ) 
			{
		  		z.r=pow(z.r,2) - pow(z.i,2);
		  		z.i=2*z.r*z.i;
		  		z.r=z.r+c.r;
		  		z.i=z.i+c.i;
		  		Abs_z=sqrt( pow(z.r,2) + pow(z.i,2) );
		  		n++;
			}
						
			data[k][l]=n;
			x=x+x_step;
		}
		    	
		y=y+y_step;
	}
	
		
	for(k=0;k<sizey;k++)                                   /* Setting Pixels in Image data */'
	{
		for(l=0;l<sizex;l++)
		{   
    		shm.image[k][l + beta]=data[k][l];
		}
	}
		
	aux_bb = shm.bb + 1;
	
	if (axu_bb == nc){
												
    	for(k=0;k<sizey;k++)
    	{
    		for(l=0;l<sizex;l++)
    	  	{
    	   		set_pixel(B, k, l, shm.image[k][l]);
    	  	}
    	}
	
    	save_image(B,"B.pgm",1);   
	
    	
	
	
    	}  
	
	
											
    shm.bb +=1;										
    
    
    while(1);										
												
												
}