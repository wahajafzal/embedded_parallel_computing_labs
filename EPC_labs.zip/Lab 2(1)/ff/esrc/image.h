struct img_s {
        int  width;
        int  hight;
	int  depth;
        char *data;
};
typedef struct img_s img;

img   *new_image(int,int);
img   *load_image(char *);
int   save_image(img *,char *,int);
void  set_pixel(img *,int,int,char);
char  get_pixel(img *,int,int);
int   image_size(img *);
