/* Epiphany Host Application */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "image.h"

#include <e-loader.h>  // Comment this line if you are using old SDK ver 5.13.09.10

#include "e-hal.h"

#define FAIL(...) { fprintf(stderr, __VA_ARGS__); exit(1); }
#define SHM_OFFSET 0x01000000



typedef struct {
    unsigned int row;
    unsigned int col;
    int bb;
    int image[64][64];

        
} shm_t;

    //unsigned int test0;
    //unsigned int test1;
    
int nc = 2;
int ncr = 1;
int ncc = 2;
clock_t start_t, end_t, total_t;


int save_image(img *a, char *filename, int binary)
{
  FILE *fp;
  int  i;
  char data[3];

    if ( (fp = fopen(filename,"w")) == NULL ) {
        return (int)NULL;    /* Could not open file */
    }

    if (binary) {
        fprintf(fp,"P5\n");
    } else {
        fprintf(fp,"P2\n");
    }

    fprintf(fp,"%d %d\n%d\n",a->width,a->hight,a->depth);

    if (binary) {
        for ( i=0; i<image_size(a) ; i++) {
            fprintf(fp,"%1c",*((a->data)+i));
        }
    } else {
        for ( i=0; i<image_size(a) ; i++) {
	    sprintf( data,"%d ",*((a->data)+i)&0x00FF );
            fprintf(fp,"%s",data);
        }
    }
    
    fclose(fp);

    return 1;
}

/* Calculates image size
 */
int image_size(img *a)
{
    return a->width * a->hight;
}


/* Allocates memory for a new image.
 *
 * Returns: Pointer to image == OK / NULL == FAIL
 */
img *new_image(int w, int h)
{
    img *a;

    if ( ( a=(img *)malloc(sizeof(img)) ) == NULL ) {
    	return (img *)NULL;
    }

    a->width = w;
    a->hight = h;
    a->depth = 255;

    if ( ( a->data = (char *)malloc(w*h) ) == NULL ) {
    	return (img *)NULL;
    }

    return a;
}


/* Sets position x,y to level
 */
void set_pixel(img *a, int x, int y, char level)
{
    if ( (x<0) || (y<0) || (y>a->hight) || (x>a->width) ) {
        printf("Out of range [%d,%d]\n",x,y);
	exit(1);
    }
    *(a->data+a->width*y+x)= level;
}



int main(int argc, char *argv[])
{
	char *filename = "bin/test.srec";
	shm_t oldshm, shm;		/* local copies of shared memory */

	e_epiphany_t dev;
	e_mem_t      emem;

	e_set_host_verbosity(H_D0);
	e_set_loader_verbosity(L_D0);

	/* init board, reset epiphany, open workgroup */
	if(e_init(NULL) != E_OK)
		FAIL("Can't init!\n");
	e_reset_system();
	if(e_open(&dev, 0, 0, 4, 4) != E_OK)
		FAIL("Can't open!\n");

	/* initialize, allocate and update shared memory buffer */
	if(e_alloc(&emem, SHM_OFFSET, sizeof(shm_t)) != E_OK)
		FAIL("Can't alloc!\n");
	if(e_write(&emem, 1, 2, (off_t)0, &shm, sizeof(shm_t)) == E_ERR)
		FAIL("Can't clear shm!\n");


    for (volatile int i = 0; i < ncr; i++){
        for (volatile int j = 0; j < ncc; j++){
    	/* load program */
        	if(e_load(filename, &dev, i, j, E_TRUE) != E_OK)
        		FAIL("Can't load!\n");
            }
        }
        
    
	/* =============================================================== */
	while(1) {
		/* poll shm states for changes */
		printf("Polling shared memory.\n");

		while(1) {
			/* read shm */
			if(e_read(&emem, 1, 2, (off_t)0, &shm,
				sizeof(shm_t)) == E_ERR)
					FAIL("Can't poll!\n");

			/* compare with previous, break if different */
			if(memcmp(&oldshm, &shm, sizeof(shm_t)))
				break;
		};

		/* print value, exit if 10 */
		printf("Processor ID (%d, %d). bb = %d\n", shm.row, shm.col, shm.bb);
		//printf("Testing (%d, %d) \n", shm.test0, shm.test1);
		

		if(shm.bb == nc)
			break;

		/* save shm */
		memcpy(&oldshm, &shm, sizeof(shm_t));
	}
	/* =============================================================== */
    
    int pic_size = 64;
    img *B;  
   	B = new_image(pic_size, pic_size);											
   	for(volatile int k=0;k<pic_size;k++)
   	{
   		for(volatile int l=0;l<pic_size;l++)
   	  	{
   	   		set_pixel(B, k, l, shm.image[k][l]);
   	  	}
   	}
   	save_image(B,"B.pgm",1);
    
    
    end_t = clock();
    printf("Total time taken by CPU: %ld\n", end_t - start_t  );
    
   /* for (volatile int i = 0; i < 64; i++){
        for (volatile int j = 0; j < 64; j++){
            if (shm.image[j][i] == 0)
                printf("%d", shm.image[j][i]);
            else
                printf("%0.0f", log(shm.image[j][i]));
        }
        printf("\n");
    }*/

	printf("Program finished.\n");

	/* free shm buffer, close workgroup and finalize */
	if(e_free(&emem) != E_OK) FAIL("Can't free!\n");
	if(e_close(&dev) != E_OK) FAIL("Can't close!\n");
	if(e_finalize() != E_OK)  FAIL("Can't finalize!\n");

	return(0);
}

